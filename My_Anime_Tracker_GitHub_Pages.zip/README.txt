MY ANIME ARCHIVE - GITHUB PAGES

1. Create a free public GitHub repository (e.g. anime-archive).
2. Upload index.html from this ZIP to the repository root.
3. In repository Settings > Pages, select Deploy from a branch, main, /(root), and Save.
4. Visit https://YOUR_USERNAME.github.io/anime-archive/ after deployment.
5. In Safari: Share > Add to Home Screen.

Changes save only in the browser on that phone. Download a JSON backup and save to iCloud Drive after updating entries. Restore using the Restore backup button.

The original 61 entries are embedded in index.html. Date ranges are labeled as recorded, and missing dates are blank. Poster images are fetched from the public Jikan API when online.
